import { useState } from 'react';
import './App.css';

function App() {
  const [TodoList, setTodoList] = useState([]);
  const [temp, setNewTemp] = useState("");

  function handleChange(event) {
    setNewTemp(event.target.value);
  };

  function addTask() {
    const taskObject = {
      id: TodoList.length === 0 ? 1 : TodoList[TodoList.length - 1].id +1,
      name:temp
    }
    setTodoList([...TodoList, taskObject]);
  };

  function deleteTask(id) {
        const tempArray = TodoList.filter((task) => ((task.id === id)?  false : true));
    setTodoList(tempArray);
  }

 

  return (
    <div className="App">

      <div className="Header">
        <h1>To-Do List</h1>
      </div>

      <div className='AddTask'>
        <input className="input" onChange={handleChange} />
        <button id= "add" className="button" onClick={addTask}> Add Task </button>
      </div>

      <div className="List">
        {TodoList.map(
          (task) => {
            return (
              <div className='itemlist'>
              <div className='tasklist'>
                <h3 className='activ'>{task.name}</h3>
              <input type="checkbox" className='checkbox' />
                <button class= "button" onClick={() => deleteTask(task.id)}>Delete</button>
              </div>
              </div>
            )
          }
        )}
      </div>
    </div>
  );

}

export default App;
